module whitman.cs370ex.jfxevents {
    requires javafx.controls;
    requires javafx.fxml;


    opens whitman.cs370ex.jfxevents to javafx.fxml;
    exports whitman.cs370ex.jfxevents;
}